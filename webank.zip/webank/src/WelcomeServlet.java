
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/WelcomeServlet")
public class WelcomeServlet extends HttpServlet {
	    
    Connection con;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		//String s1=request.getParameter("uname");
		//String s2=request.getParameter("pword");
		
		System.out.print("web bank");
		HttpSession hs=request.getSession();
		
		String un=(String)hs.getAttribute("uname");
		String pwd=(String)hs.getAttribute("pword");
		
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
			System.out.println("Database connection established successfully in Customer welcome servlet");
			
		PreparedStatement pstmt=con.prepareStatement("select * from customer where user_id=? and pword=?");
		
		if( ! un.equals(null) && ! pwd.equals(null))
		{
			pstmt.setString(1, un);
			pstmt.setString(2, pwd);
		}
		
		
		PrintWriter pw=response.getWriter();
		
		
		ResultSet rs=pstmt.executeQuery();
	
		rs.next();
		
		
		
		
		Cookie c1=new Cookie("lname",rs.getString(2));
		Cookie c2=new Cookie("AccountNo",rs.getString(6));
		Cookie c3=new Cookie("bal",rs.getString(8));
		
		response.addCookie(c1);
		response.addCookie(c2);
		response.addCookie(c3);
		
		response.setContentType("text/html");
		
		pw.println("<html>");
		pw.println("<head>");
		pw.println("<title>");
		pw.println("Welcome Page");
		pw.println("</TITLE>");
		pw.println("</head>");
		pw.println("<body background='https://camo.githubusercontent.com/161566499195bcae38b872e7b34ec18e9ff52180/687474703a2f2f692e696d6775722e636f6d2f744735644948782e6a7067'>");
		pw.println("<strong><a href=aboutus.html>About Us</a></strong> ");
		pw.println("<strong><a href=contactus.html>Contact Us</a></strong> ");
		pw.println("<strong><a href=changecredentials.html >Change User Credentials</a></strong>");
		pw.println("<strong><a href=logout>Log out</a></strong> <br />");
		
		
		pw.println("<hr />");
		pw.println("<html> <h4>Welcome <em>"+rs.getString(2)+"</em></h4>");
		
		
		pw.println("Account Number  : <strong>"+rs.getString(6)+"</strong>");
		pw.println("<br />Your current Balance  : <strong> Rs "+rs.getString(8)+"</strong>");
		
		
		
		pw.println("<h3>Menu</h3>");
		pw.println("<ul> <li>   <a href=FTWithin.html>Funds Transfer With in Bank</a></li>");
		pw.println("<br /> <li> <a href=Ftother.html>Funds Transfer to Other Bank</a></li>");
		pw.println("<br /><li> <a href=complaint.html>Register a Complaint</a></li>");
		pw.println("<br /><li> <a href=ComplaintBase>View Complaints'status</a></li>");
		pw.println("<br /><li> <a href=ViewTrans>View Transactions</a></li>");
		pw.println("<br /><li> <a href=changecredentials.html >Change User Credentials</a></li>");
		pw.println("<br /><li> <a href=LogOut>Log out</a></li></ul>");
		
		
		}
		catch(Exception e){
			System.err.println(e);
		}
		
	}

}
